<!-- Labwork 4.1.3 Courses
		By: Timothy Wright -->

<HTML>
<HEAD>

<TITLE>Course Information - Get Method</TITLE>
</HEAD>
<BODY>

<Form Method="GET" Action="Courses.php">

<p>Select a Course to learn more about it:<BR> </p>

<Select Name="Course" Size="4">


<Option Value="Computer Hardware: 4 Credits, Taught by: Dr. Drexel">CS2200</Option>
<Option Value="Visual Basic: 3 Credits, Taught by: Dr. Marshall">CS2080</Option>
<Option Value="Data Structures: 4 Credits, Taught by: Prof. Burke">CS2381</Option>
<Option Value="Web Programming: 3 Credits, Taught by: Prof. Porter">CS3020</Option>
</Select>


<p><Input Type="submit" Name="Submit" Value="Select"></p>
</Form>
</BODY></HTML>
