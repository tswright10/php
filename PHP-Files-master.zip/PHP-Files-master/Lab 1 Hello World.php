<HTML>
<HEAD>
<TITLE>My first php file</TITLE>
</HEAD>
<BODY>
<?php

print("My name is Timothy Wright. ");
print("My first PhP script now works.");
//phpinfo()

?>
</BODY>
</HTML>