<!-- Labwork 4.2 Factorials - Post Method 
		By: Timothy Wright -->

<html> 
<head> 
<title>Factorials - Using the Get Method</title> 
</head> 
<body> 

<Form Method="Post" Action="Lab 4-2 Post.php">
<p><BR>Enter a Number: </p>
<input type="Integer" name="Integer"><BR>

<p><Input Type="Submit" Name="Submit" Value="Submit"></p>
</form>

</body> 
</html>