<!-- Labwork 4.1.3 Courses
		By: Timothy Wright -->

<HTML>
<HEAD>

<TITLE>PSU Courses</TITLE>
<Style type="text/css">

</Style>
</HEAD>
<BODY>

<p>Course Description: <?php echo $_GET["Course"]; ?> </p>
</BODY>
</HTML>