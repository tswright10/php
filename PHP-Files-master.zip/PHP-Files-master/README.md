# PHP-Files
Php Files completed during undergraduate information technology degree at Plymouth State University

These files contain some basic php labs that can be utilized in homework assignments. The files include everything from a simple 'Hello World' to more complex string operations and mutli array handling. 

I hope these files can help you in your course work or even to help start off writing php. 

All file credit to Timothy Wright.
