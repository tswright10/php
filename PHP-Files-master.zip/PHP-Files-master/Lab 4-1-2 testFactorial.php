<!-- Labwork 4.1.2 Factorials - Get Method
		By: Timothy Wright -->

<html> 
<head> 
<title>Factorials - Using the Get Method</title> 
</head> 
<body> 

<Form Method="Get" Action="Lab 4-1-2 Factorial.php">
<p><BR>Enter a Number: </p>
<input type="Integer" name="Integer"><BR>

<p><Input Type="Submit" Name="Submit" Value="Submit"></p>
</form>

</body> 
</html>