<!-- Labwork 4.2Courses
		By: Timothy Wright -->

<HTML>
<HEAD>

<TITLE>PSU Courses</TITLE>
<Style type="text/css">

</Style>
</HEAD>
<BODY>

<p>Course Description: <?php echo $_POST["Course"]; ?> </p>
</BODY>
</HTML>